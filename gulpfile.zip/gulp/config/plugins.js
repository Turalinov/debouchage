import plumber from 'gulp-plumber'; // обработка ошибок
import notify from 'gulp-notify'; // для уведомления ошибок (сообщения и подсказки)
import replace from 'gulp-replace'; //поиск и замена
import ifPlugin from 'gulp-if'; //условное ветвление
import browsersync from 'browser-sync'; // //локальный сервер
import concat from 'gulp-concat'; // для объединения несколько файлов в одинобъединенияобъединенияобъединенияобъединения
import newer from 'gulp-newer'; //проверка

export const plugins = {
	plumber: plumber,
	notify: notify,
	replace: replace,
	if: ifPlugin,
	browsersync: browsersync,
	concat: concat,
	newer: newer,
};
