//импортируем модуль path из node.js
import * as nodePath from 'path';

//получаем название папки "config"
const rootFolder = nodePath.basename(nodePath.resolve());

const buildFolder = './docs';
const srcFolder = './src';

export const path = {
	build: {
		js: `${buildFolder}/js/`,
		images: `${buildFolder}/img/`,
		css: `${buildFolder}/css/`,
		html: `${buildFolder}/`,
		fonts: `${buildFolder}/fonts/`,
		svgicons: `${buildFolder}/img/icons/`,
		favicon: `${buildFolder}/img/favicon/`,
		php: `${buildFolder}/`,
		phpMailer: `${buildFolder}/PHPMailer/`,
		vendor: `${buildFolder}/vendor/`,
	},
	src: {
		js: `${srcFolder}/js/bundle.js`,
		images: `${srcFolder}/img/*.{jpg,jpeg,png,gif,webp,svg}`,
		scss: `${srcFolder}/scss/style.scss`,
		html: `${srcFolder}/*.html`,
		svgicons: `${srcFolder}/img/icons/*.svg`,
		favicon: `${srcFolder}/img/favicon/**/*.*`,
		php: `${srcFolder}/*.php`,
		phpMailer: `${srcFolder}/PHPMailer/*/**`,
		vendor: `${srcFolder}/vendor/**/*`,
	},
	watch: {
		js: `${srcFolder}/js/**/*.js`,
		images: `${srcFolder}/img/*.{jpg,jpeg,png,gif,webp,svg}`,
		scss: `${srcFolder}/scss/**/*.scss`,
		html: `${srcFolder}/**/*.html`,
		svgicons: `${srcFolder}/img/icons/*.svg`,
		php: `${srcFolder}/*.php`,
		vendor: `${srcFolder}/vendor/**/*`,
	},
	clean: buildFolder,
	buildFolder: buildFolder,
	srcFolder: srcFolder,
	rootFolder: rootFolder,
	styleLibs: ['./node_modules/normalize.css/normalize.css'],
};
