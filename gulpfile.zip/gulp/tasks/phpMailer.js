/* eslint-disable no-undef */
export const phpMailer = () => {
	return app.gulp.src(app.path.src.phpMailer)
		.pipe(app.gulp.dest(app.path.build.phpMailer));
};



