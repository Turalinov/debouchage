/* eslint-disable no-undef */
import svgSprite from 'gulp-svg-sprite'; // для создания спрайта
import svgo from 'gulp-svgo'; // для удаления ненужных свойств в svg

export const icons = () => {
	return app.gulp
		.src(`${app.path.src.svgicons}`, {})
		.pipe(
			app.plugins.plumber(
				app.plugins.notify.onError({
					title: 'SVG',
					message: 'Error: <%= error.message %>',
				})
			)
		)
		.pipe(
			svgo({
				plugins: [
					{
						removeAttrs: { attrs: '(xmlns)' }, //stroke|style|width|height|data.*
					},
				],
			})
		)
		.pipe(
			svgSprite({
				mode: {
					symbol: {
						sprite: '../sprite.svg',
						//создавать страницу с перечнем иконок
						// example: true
					},
				},
			})
		)
		.pipe(app.gulp.dest(`${app.path.build.svgicons}`));
};
