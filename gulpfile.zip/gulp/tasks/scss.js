/* eslint-disable no-undef */
import dartSass from 'sass'; //реализация sass чистом js. дистрибутив Dart Sass
import gulpSass from 'gulp-sass'; //плагин sass для gulp
import rename from 'gulp-rename'; //плагин для простого переименования файлов.

import sassGlob from 'gulp-sass-glob'; // sassGlob  -для поддержки подключения файлов scss через * паттерн в @import

import cleanCss from 'gulp-clean-css'; //сжатие css файла (минификация) удаляет комментарий и минифицирует в одну строку
import webpcss from 'gulp-webpcss'; // вывод стилей для webp избражений с классом .webp
import autoprefixer from 'gulp-autoprefixer'; //добавление вендорных префиксов
import groupCssMediaQueries from 'gulp-group-css-media-queries'; // группировка медиа запросов

const sass = gulpSass(dartSass);

export const scss = () => {
	return (
		app.gulp
			.src([...app.path.styleLibs, app.path.src.scss], {
				soursemaps: app.isDev,
			})
			.pipe(app.plugins.concat('main.scss'))
			.pipe(
				app.plugins.plumber(
					app.plugins.notify.onError({
						title: 'SCSS',
						message: 'Error: <%= error.message%>',
					})
				)
			)
			.pipe(sassGlob())
			.pipe(app.plugins.replace(/@img\//g, '../img/'))
			.pipe(
				sass({
					outputStyle: 'expanded',
				})
			)
			.pipe(app.plugins.if(app.isBuild, groupCssMediaQueries()))
			.pipe(
				app.plugins.if(
					app.isBuild,
					webpcss({
						webpClass: '.webp',
						noWebpClass: '.no-webp',
					})
				)
			)
			.pipe(
				app.plugins.if(
					app.isBuild,
					autoprefixer({
						grid: true,
						ovverrideBrowsersList: ['last 3 versions'],
						cascade: true,
					})
				)
			)
		//раскомментировать если нужен не сжатый дубль файла стилей
			.pipe(app.gulp.dest(app.path.build.css))
			.pipe(app.plugins.if(app.isBuild, cleanCss()))
			.pipe(
				rename({
					extname: '.min.css',
				})
			)
			.pipe(app.gulp.dest(app.path.build.css))
			.pipe(app.plugins.browsersync.stream())
	);
};
