/* eslint-disable no-undef */
import webp from 'gulp-webp'; //Преобразование изображений в WebP
import imagemin from 'gulp-imagemin'; //Оптимизация изображений PNG, JPEG, GIF и SVG

import imageminGiflossy from 'imagemin-giflossy';
import imageminPngquant from 'imagemin-pngquant';
import imageminZopfli from 'imagemin-zopfli';
import imageminMozjpeg from 'imagemin-mozjpeg';

export const images = () => {
	return app.gulp
		.src(app.path.src.images)
		.pipe(
			app.plugins.plumber(
				app.plugins.notify.onError({
					title: 'IMAGES',
					message: 'Error: <%= error.message %>',
				})
			)
		)
		.pipe(app.plugins.newer(app.path.build.images))

		// .pipe(app.plugins.if(app.isBuild, webp()))
		.pipe(app.plugins.if(app.isBuild, app.gulp.dest(app.path.build.images)))
		.pipe(app.plugins.if(app.isBuild, app.gulp.src(app.path.src.images)))
		.pipe(app.plugins.if(app.isBuild, app.plugins.newer(app.path.build.images)))
		.pipe(app.plugins.if(app.isBuild, imagemin([
			imageminGiflossy({
				optimizationLevel: 3,
				optimize: 3,
				lossy: 2
			}),
			imageminPngquant({
				speed: 5,
				quality: [0.6, 0.8]
			}),
			imageminZopfli({
				more: true
			}),
			imageminMozjpeg({
				progressive: true,
				quality: 90
			}),
			imagemin.svgo({
				plugins: [
					{ removeViewBox: false },
					{ removeUnusedNS: false },
					{ removeUselessStrokeAndFill: false },
					{ cleanupIDs: false },
					{ removeComments: true },
					{ removeEmptyAttrs: true },
					{ removeEmptyText: true },
					{ collapseGroups: true }
				]
			})
		])))



		.pipe(app.gulp.dest(app.path.build.images))
		.pipe(app.plugins.browsersync.stream());
};



