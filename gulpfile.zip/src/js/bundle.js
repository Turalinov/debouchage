import console from './modules/console.js';
console();

