export default function console() {
  console.log('console');
}
